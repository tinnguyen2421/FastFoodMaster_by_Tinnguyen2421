package com.example.appfood_by_tinnguyen2421;
//May not be copied in any form
//Copyright belongs to Nguyen TrongTin. contact: email:tinnguyen2421@gmail.com
public class User {

    String Role;

    public User(String role)
    {
        Role=role;
    }
}
