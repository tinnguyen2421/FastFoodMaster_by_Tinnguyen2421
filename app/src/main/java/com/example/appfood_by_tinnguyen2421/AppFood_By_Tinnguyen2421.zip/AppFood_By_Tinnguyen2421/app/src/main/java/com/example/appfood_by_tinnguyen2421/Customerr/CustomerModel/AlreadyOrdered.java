package com.example.appfood_by_tinnguyen2421.Customerr.CustomerModel;
//May not be copied in any form
//Copyright belongs to Nguyen TrongTin. contact: email:tinnguyen2421@gmail.com
public class AlreadyOrdered {

   private String isOrdered;

    public AlreadyOrdered(String isOrdered) {
        this.isOrdered = isOrdered;
    }

    public AlreadyOrdered()
    {

    }

    public String getIsOrdered() {
        return isOrdered;
    }

    public void setIsOrdered(String isOrdered) {
        this.isOrdered = isOrdered;
    }
}
