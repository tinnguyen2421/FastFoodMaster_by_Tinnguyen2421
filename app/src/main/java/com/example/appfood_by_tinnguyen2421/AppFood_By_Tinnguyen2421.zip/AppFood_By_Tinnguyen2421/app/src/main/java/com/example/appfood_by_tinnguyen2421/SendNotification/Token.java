package com.example.appfood_by_tinnguyen2421.SendNotification;
//May not be copied in any form
//Copyright belongs to Nguyen TrongTin. contact: email:tinnguyen2421@gmail.com
public class Token {

    private String token;

    public  Token(String token)
    {
        this.token=token;

    }

    public Token()
    {

    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
