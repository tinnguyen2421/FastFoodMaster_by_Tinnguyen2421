package com.example.appfood_by_tinnguyen2421.Chef.ChefAdapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.example.appfood_by_tinnguyen2421.Chef.ChefActivity.ChefPreparedOrder;
import com.example.appfood_by_tinnguyen2421.Chef.ChefActivity.ChefPreparedOrderView;
import com.example.appfood_by_tinnguyen2421.Chef.ChefModel.ChefFinalOrders1;
import com.example.appfood_by_tinnguyen2421.R;

import java.util.List;
//May not be copied in any form
//Copyright belongs to Nguyen TrongTin. contact: email:tinnguyen2421@gmail.com
public class ChefPreparedOrderAdapter extends RecyclerView.Adapter<ChefPreparedOrderAdapter.ViewHolder> {

    private Context context;
    private List<ChefFinalOrders1> chefFinalOrders1list;

    public ChefPreparedOrderAdapter(Context context, List<ChefFinalOrders1> chefFinalOrders1list) {
        this.chefFinalOrders1list = chefFinalOrders1list;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.chef_preparedorder, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final ChefFinalOrders1 chefFinalOrders1 = chefFinalOrders1list.get(position);
        holder.Address.setText("Số thứ tự:"+position+1);
        holder.Address.setText("Địa chỉ:"+chefFinalOrders1.getAddress());
        holder.grandtotalprice.setText("Tổng số tiền: " + chefFinalOrders1.getGrandTotalPrice()+"đ");
        final String random = chefFinalOrders1.getRandomUID();

        holder.Vieworder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, ChefPreparedOrderView.class);
                intent.putExtra("RandomUID", random);
                context.startActivity(intent);
                ((ChefPreparedOrder) context).finish();
            }
        });

    }

    @Override
    public int getItemCount() {
        return chefFinalOrders1list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView Address, grandtotalprice,STT1;
        Button Vieworder;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            STT1=itemView.findViewById(R.id.STT);
            Address = itemView.findViewById(R.id.customer_address);
            grandtotalprice = itemView.findViewById(R.id.customer_totalprice);
            Vieworder = itemView.findViewById(R.id.View);
        }
    }
}
